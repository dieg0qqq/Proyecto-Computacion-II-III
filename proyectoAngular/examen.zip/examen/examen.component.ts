import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AnaTextoService } from "../ana-texto.service";

@Component({
  selector: 'app-examen',
  templateUrl: './examen.component.html',
  styleUrls: ['./examen.component.scss']
})
export class ExamenComponent implements OnInit {

  constructor(private http: HttpClient, private AnaTextoService: AnaTextoService) { }
  lista: Array<string> = []
  miTexto: Text;
  texto: String;
  pos_por: String;
  neg_por: String;
  neu_por: String;
  compound: String;
  conclusion: String;
  idioma: String;

  ngOnInit(): void {
  }
  analizar() {
    var anali;
    var media;
    var i = 0
    var fila;
    var d1 = document.getElementById("cambio");
    for (i; i < this.lista.length; i++) {
      console.log(this.lista[i])
      this.AnaTextoService.analisis(this.lista[i]).subscribe(
        data => {
          anali = data as JSON;
          this.texto = anali['texto'];
          this.pos_por = anali['%pos'];
          this.neg_por = anali['%neg'];
          this.neu_por = anali['%neu'];
          this.compound = anali['compound'];
          this.conclusion = anali['conclusion'];
          this.idioma = anali['idioma'];
          if (this.conclusion == 'Positivo') {
            fila =
              "<div id=\"DivCambiado\">" +
              "<h4>Texto introducido: </h4><label id =\"positivo\">" + this.texto + "</label >" +
              "<h4>Análisis del texto: </h4><label>" + this.conclusion + "</label >" +
              "<div id=\"accordion\">" +
              "<div id=\"headingOne\">" +
              "<h5 class=\"mb-0\" >" +
              "<button class=\"btn btn-link\" data-toggle=\"collapse\" data-target=\"#collapseOne\" aria-controls=\"collapseOne\" >" +
              "Informacion adicional <i class=\"fas fa-plus-circle\"></i> " +
              "</button>" +
              "</h5>" +
              "</div>" +
              "<div id = \"collapseOne\" class=\"collapse\" aria-labelledby=\"headingOne\" data-parent=\"#accordion\" >" +
              "<div>" +
              "<ul>" +
              "<li>" +
              "Compound: <label>" + this.compound + "</label>" +
              "</li>" +
              "<li>" +
              "Porcentajes:" +
              "<ul>" +
              "<li>" +
              "Positivo(%): <label>" + this.pos_por + "</label>" +
              "</li>" +
              "<li>" +
              "Negativo(%): <label>" + this.neg_por + "</label>" +
              "</li>" +
              "<li>" +
              "Neutro(%): <label>" + this.neu_por + "</label>" +
              "</li>" +
              "</ul>" +
              "</li>" +
              "</ul>" +
              "</div>" +
              "</div>";
          }
          else if (this.conclusion == 'Negativo') {
            fila =
              "<div id=\"DivCambiado\">" +
              "<h4>Texto introducido: </h4><label id =\"negativo\">" + this.texto + "</label >" +
              "<h4>Análisis del texto: </h4><label>" + this.conclusion + "</label >" +
              "<div id=\"accordion\">" +
              "<div id=\"headingOne\">" +
              "<h5 class=\"mb-0\" >" +
              "<button class=\"btn btn-link\" data-toggle=\"collapse\" data-target=\"#collapseOne\" aria-controls=\"collapseOne\" >" +
              "Informacion adicional <i class=\"fas fa-plus-circle\"></i> " +
              "</button>" +
              "</h5>" +
              "</div>" +
              "<div id = \"collapseOne\" class=\"collapse\" aria-labelledby=\"headingOne\" data-parent=\"#accordion\" >" +
              "<div>" +
              "<ul>" +
              "<li>" +
              "Compound: <label>" + this.compound + "</label>" +
              "</li>" +
              "<li>" +
              "Porcentajes:" +
              "<ul>" +
              "<li>" +
              "Positivo(%): <label>" + this.pos_por + "</label>" +
              "</li>" +
              "<li>" +
              "Negativo(%): <label>" + this.neg_por + "</label>" +
              "</li>" +
              "<li>" +
              "Neutro(%): <label>" + this.neu_por + "</label>" +
              "</li>" +
              "</ul>" +
              "</li>" +
              "</ul>" +
              "</div>" +
              "</div>";
          }
          else {
            fila =
              "<div id=\"DivCambiado\">" +
              "<h4>Texto introducido: </h4><label>" + this.texto + "</label >" +
              "<h4>Análisis del texto: </h4><label id= \"neutral\">" + this.conclusion + "</label >" +
              "<div id=\"accordion\">" +
              "<div id=\"headingOne\">" +
              "<h5 class=\"mb-0\" >" +
              "<button class=\"btn btn-link\" data-toggle=\"collapse\" data-target=\"#collapseOne\" aria-controls=\"collapseOne\" >" +
              "Informacion adicional <i class=\"fas fa-plus-circle\"></i> " +
              "</button>" +
              "</h5>" +
              "</div>" +
              "<div id = \"collapseOne\" class=\"collapse\" aria-labelledby=\"headingOne\" data-parent=\"#accordion\" >" +
              "<div>" +
              "<ul>" +
              "<li>" +
              "Compound: <label>" + this.compound + "</label>" +
              "</li>" +
              "<li>" +
              "Porcentajes:" +
              "<ul>" +
              "<li>" +
              "Positivo(%): <label>" + this.pos_por + "</label>" +
              "</li>" +
              "<li>" +
              "Negativo(%): <label>" + this.neg_por + "</label>" +
              "</li>" +
              "<li>" +
              "Neutro(%): <label>" + this.neu_por + "</label>" +
              "</li>" +
              "</ul>" +
              "</li>" +
              "</ul>" +
              "</div>" +
              "</div>";
          }
          
          d1.insertAdjacentHTML('beforeend', fila);
          if (this.conclusion =='positivo') {
            media = media + 1;
          }
          else if (this.conclusion == 'negativo') {
            media = media - 1;
          }
          else {
            media = media + 0;
          }
          if (media < 0) {
            document.getElementById("media").innerHTML = "Negativo"
          }
          else if (media > 0 ) {
            document.getElementById("media").innerHTML = "Positivo"
          }
          else {
            document.getElementById("media").innerHTML = "Neutral"
          }
        }
        
      );
        

    }
  }
  mostrar() {
    var aux;
    var anali;
    var fila = '';
    var d1 = document.getElementById("tabla");
    aux = this.miTexto
    this.lista.push(aux)
    var i=0
    for(i ; i < this.lista.length; i++) { 
      fila = '<tr>' +
        '<td>' + (i + 1) + '</td>' +
        '<td>' + this.lista[i] + '</td>' +
        '</tr>';
    }
    d1.insertAdjacentHTML('beforeend', fila);
  }

}
